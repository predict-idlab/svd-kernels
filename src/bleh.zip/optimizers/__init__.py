from abc import ABC

import tensorflow as tf
from tensorflow.python.eager import context
from tensorflow.python.framework import ops
from tensorflow.python.ops import control_flow_ops
from tensorflow.python.ops import math_ops
from tensorflow.python.ops import resource_variable_ops
from tensorflow.python.ops import state_ops
from tensorflow.python.training import optimizer
from tensorflow.python.training import training_ops

# https://github.com/tensorflow/tensorflow/blob/master/tensorflow/python/training/adam.py


class SVDMomentumOptimizer(tf.keras.optimizers.Optimizer):
    def __init__(self, learning_rate=0.01, beta=0.9, epsilon=10e-8, name="SVDMomentumOptimizer", **kwargs):
        """Call super().__init__() and use _set_hyper() to store hyperparameters"""
        super().__init__(name, **kwargs)
        self._lr = learning_rate
        self._beta = beta
        self._epsilon = epsilon
        self._is_first = True

        self._lr_t = None
        self._beta_t = None
        self._epsilon_t = None

    def _prepare(self, var_list):
        lr = self._call_if_callable(self._lr)
        beta = self._call_if_callable(self._beta)
        epsilon = self._call_if_callable(self._epsilon)

        self._lr_t = ops.convert_to_tensor(lr, name="learning_rate")
        self._beta_t = ops.convert_to_tensor(beta, name="beta1")
        self._epsilon_t = ops.convert_to_tensor(epsilon, name="epsilon")

    def _create_slots(self, var_list):
        """For each model variable, create the optimizer variable associated with it.
        TensorFlow calls these optimizer variables "slots".
        For momentum optimization, we need one momentum slot per model variable.
        """
        for var in var_list:
            self.add_slot(var, "current_value") # current variable value
            self.add_slot(var, "previous_value")  # previous variable i.e. weight or bias
            self.add_slot(var, "momentum")  # previous gradient

    @tf.function
    def _resource_apply_dense(self, grad, var, apply_state):
        """Update the slots and perform one optimization step for one model variable
        """
        def singular(var, lr_t):
            return None

        def phi(var, lr_t):
            return None

        # get hyperparameters
        lr_t = self._lr_t
        beta = self._beta_t
        # update gradient and learning rate
        momentum = beta * self.get_slot(var, "momentum") + grad
        # update variable
        new_var = phi(var, lr_t)@var if condition(var.name) else singular(var, lr_t)
        # update current value
        var.assign(new_var)
        self.get_slot(var, "current_value").assign(new_var)

    def _resource_apply_sparse(self, grad, handle, indices, apply_state):
        raise NotImplementedError

    def get_config(self):
        base_config = super().get_config()
        return {
            **base_config,
            "learning_rate": self._serialize_hyperparameter("learning_rate"),
        }

    def apply_gradients(self,
                      grads_and_vars,
                      name=None,
                      experimental_aggregate_gradients=True):
