from typing import *
from typing import Dict, List, Any, Union

import tensorflow as tf

from numpy import concatenate, array
from src.layers import EncoderLayer, DecoderLayer, PositionalEncodingLayer, CAEncoderLayer, CADecoderLayer
from .utils import *


"""
Decomposition based models
"""


class SVDFeedForward(tf.keras.models.Model):
    def __init__(self, architecture: dict):
        """Initialize model."""
        super(SVDFeedForward, self).__init__()

    def build(self, input_shape):
        """Build function"""
        raise NotImplementedError

    def __call__(self, inputs, training):
        """Call function."""
        raise NotImplementedError

    def train_step(self, data):
        """Training step"""
        # Unpack
        x, y = data
        # Get learning rate
        lr = self.optimizer.learning_rate
        # Get gradients
        with tf.GradientTape() as tape:
            y_pred = self(x, training=True)
            loss = self.compiled_loss(y, y_pred, regularization_losses=self.losses)
            trainable_variables = self.trainable_variables
            gradients = tape.gradient(loss, trainable_variables)
        # Make gradients and variables zip
        grads_and_vars = zip(trainable_variables, gradients)
        # Optimize svd layers
        for layer in (layer for layer in self.layers if 'svd' in layer.name):
            # Get layer component names
            layer_variables = ['/'.join([self.name, layer.name, suffix]) for suffix in['U:0', 'S:0', 'V:0']]
            # Get gradients and variables for components
            (u, s, v), (du, ds, dv) = zip(*[(v, g) for v, g in grads_and_vars if v.name in layer_variables])
            # Update gradients and variables zip to not contain these layer's components
            grads_and_vars = [(v, g) for v, g in grads_and_vars if v.name not in layer_variables]
            # update svd variables
            update_svd(u, s, v, du, ds, dv, lr, lr, lr)
        # apply remainder of regular variables
        self.optimizer.apply_gradients(grads_and_vars)


"""
Transformer 
"""


class Encoder(tf.keras.models.Model):
    def __init__(self, num_layers, d_model, num_heads, dff, input_vocab_size,
                 maximum_position_encoding, rate=0.1):
        super(Encoder, self).__init__()

        self.d_model = d_model
        self.num_layers = num_layers

        self.embedding = tf.keras.layers.Embedding(input_vocab_size, d_model)
        self.positional_encoding = PositionalEncodingLayer(maximum_position_encoding, self.d_model)

        self.encoder_layers = [EncoderLayer(d_model, num_heads, dff, rate) for _ in range(num_layers)]

        self.dropout = tf.keras.layers.Dropout(rate)

    def __call__(self, inputs, training, mask):
        seq_len = tf.shape(inputs)[1]

        # adding embedding and position encoding.
        inputs = self.embedding(inputs)  # (batch_size, input_seq_len, d_model)
        inputs = self.positional_encoding(inputs, seq_len)

        inputs = self.dropout(inputs, training=training)

        for layer in self.encoder_layers:
            inputs = self.layer(inputs, training, mask)

        return inputs  # (batch_size, input_seq_len, d_model)


class Decoder(tf.keras.models.Model):
    def __init__(self, num_layers, d_model, num_heads, dff, target_vocab_size,
                 maximum_position_encoding, rate=0.1):
        super(Decoder, self).__init__()

        self.d_model = d_model
        self.num_layers = num_layers

        self.embedding = tf.keras.layers.Embedding(target_vocab_size, d_model)
        self.positional_encoding = PositionalEncodingLayer(maximum_position_encoding, d_model)

        self.decoder_layers = [DecoderLayer(d_model, num_heads, dff, rate) for _ in range(num_layers)]
        self.dropout = tf.keras.layers.Dropout(rate)

    def __call__(self, inputs, enc_output, training, look_ahead_mask, padding_mask):
        attention_weights = {}
        seq_len = tf.shape(inputs)[1]

        # adding embedding and position encoding.
        inputs = self.embedding(inputs)  # (batch_size, input_seq_len, d_model)
        inputs = self.positional_encoding(inputs, seq_len)

        inputs = self.dropout(inputs, training=training)

        for i, layer in enumerate(self.decoder_layers):
            inputs, weights = layer(inputs, enc_output, training, look_ahead_mask, padding_mask)

            attention_weights[f'decoder_layer{i + 1}'] = weights

        # x.shape == (batch_size, target_seq_len, d_model)
        return inputs, attention_weights


class Transformer(tf.keras.Model):
    def __init__(self, num_layers: int, d_model: int, num_heads: int, dff: int,
                 input_vocab_size: int, target_vocab_size: int, pe_input: int, pe_target: int, rate: float = 0.1):
        super(Transformer, self).__init__()

        self.encoder = Encoder(num_layers, d_model, num_heads, dff, input_vocab_size, pe_input, rate)
        self.decoder = Decoder(num_layers, d_model, num_heads, dff, target_vocab_size, pe_target, rate)

        self.final_layer = tf.keras.layers.Dense(target_vocab_size)

    def __call__(self, inputs, targets, training, enc_padding_mask, look_ahead_mask, dec_padding_mask):
        # (batch_size, inp_seq_len, d_model)
        encoded_inputs = self.encoder(inputs, training, enc_padding_mask)
        # dec_output.shape == (batch_size, tar_seq_len, d_model)
        decoded_inputs, weights = self.decoder(targets, encoded_inputs, training, look_ahead_mask, dec_padding_mask)
        # (batch_size, tar_seq_len, target_vocab_size)
        final_output = self.final_layer(decoded_inputs)

        return final_output, weights

    @staticmethod
    @tf.function
    def create_masks(inp, tar):
        # Encoder padding mask
        enc_padding_mask = create_padding_mask(inp)

        # Used in the 2nd attention block in the decoder.
        # This padding mask is used to mask the encoder outputs.
        dec_padding_mask = create_padding_mask(inp)

        # Used in the 1st attention block in the decoder.
        # It is used to pad and mask future tokens in the input received by
        # the decoder.
        look_ahead_mask = create_look_ahead_mask(tf.shape(tar)[1])
        dec_target_padding_mask = create_padding_mask(tar)
        combined_mask = tf.maximum(dec_target_padding_mask, look_ahead_mask)

        return enc_padding_mask, combined_mask, dec_padding_mask

    @tf.function
    def train_step(self, inputs, targets, train_loss, train_metrics):
        targets_input = targets[:, :-1]
        targets_real = targets[:, 1:]

        enc_padding_mask, combined_mask, dec_padding_mask = self.create_masks(inputs, targets_input)

        with tf.GradientTape() as tape:
            predictions, _ = self(inputs, targets_input, True, enc_padding_mask, combined_mask, dec_padding_mask)
            loss = self.loss_function(targets_real, predictions)

            gradients = tape.gradient(loss, self.trainable_variables)
            self.optimizer.apply_gradients(zip(gradients, self.trainable_variables))

        # Add train loss and metrics
        train_loss(loss)
        for train_metric in train_metrics:
            train_metric(targets_real, predictions)

    def train(self, train_ds: tf.keras.datasets.Dataset, optimizer: tf.keras.optimizers.Optimizer,
              validation_ds: Optional[tf.keras.datasets.Dataset] = None,
              epochs: int = 1, train_loss: str = 'mse', train_metrics=None, validation_metrics=None,
              verbose: int=1, save_ckpt: int = 5, ckpt_path: Optional[str] = None):
        if ckpt_path is not None:
            _ckpt = tf.train.Checkpoint(transformer=self, optimizer=optimizer)
            _ckpt_manager=tf.train.CheckpointManager(_ckpt, ckpt_path, max_to_keep=5)

        train_loss = tf.keras.losses.get(train_loss)
        for epoch in range(epochs):
            # reset states
            train_loss.reset_states()
            for train_metric in train_metrics:
                train_metric.reset_states()
            if validation_metrics is not None:
                for validation_metric in validation_metrics:
                    validation_metric.reset_states()
            else:
                pass

            # training step
            for (batch, (inputs, targets)) in enumerate(train_ds):
                self.train_step(inputs, targets)

            if (epoch + 1) % verbose == 0:
                print(f'Epoch {epoch}, Loss {train_loss:.4f}' + ', '.join(['train_metrics']))
                print(f'Epoch {epoch}, Loss {train_loss:.4f}' + ', '.join(['validation_metrics']))

            if ((epoch + 1) % save_ckpt == 0) & (ckpt_path is not None):
                ckpt_save_path = _ckpt_manager.save()
                print('Saving checkpoint for epoch {} at {}'.format(epoch + 1, ckpt_save_path))

    def predict(self,
              x,
              batch_size=None,
              verbose=0,
              steps=None,
              callbacks=None,
              max_queue_size=10,
              workers=1,
              use_multiprocessing=False):
        raise NotImplementedError

    # def evaluate(self, input_sentence, tokenizer, vocab_size):
    #     start_token = [vocab_size]
    #     end_token = [vocab_size + 1]
    #
    #     # inp sentence is portuguese, hence adding the start and end token
    #     inp_sentence = start_token + tokenizer.encode(input_sentence) + end_token
    #     encoder_input = tf.expand_dims(inp_sentence, 0)
    #
    #     # as the target is english, the first word to the transformer should be the
    #     # english start token.
    #     decoder_input = [vocab_size]
    #     output = tf.expand_dims(decoder_input, 0)
    #
    #     for i in range(MAX_LENGTH):
    #         enc_padding_mask, combined_mask, dec_padding_mask = create_masks(
    #             encoder_input, output)
    #
    #         # predictions.shape == (batch_size, seq_len, vocab_size)
    #         predictions, attention_weights = self(encoder_input,
    #                                                      output,
    #                                                      False,
    #                                                      enc_padding_mask,
    #                                                      combined_mask,
    #                                                      dec_padding_mask)
    #
    #         # select the last word from the seq_len dimension
    #         predictions = predictions[:, -1:, :]  # (batch_size, 1, vocab_size)
    #
    #         predicted_id = tf.cast(tf.argmax(predictions, axis=-1), tf.int32)
    #
    #         # return the result if the predicted_id is equal to the end token
    #         if predicted_id == vocab_size + 1:
    #             return tf.squeeze(output, axis=0), attention_weights
    #
    #         # concatentate the predicted_id to the output which is given to the decoder
    #         # as its input.
    #         output = tf.concat([output, predicted_id], axis=-1)
    #
    #     return tf.squeeze(output, axis=0), attention_weights


"""
Context aware feed forward
"""

class CAFeedForward(tf.keras.models.Model):


"""
Context aware transformer
"""


class CAEncoder(tf.keras.models.Model):
    def __init__(self, num_layers: int, d_model: int, num_heads: int, dff: int, maximum_position_encoding: int,
                 input_vocab_size: Optional[int] = None, context_vocab_size: Optional[int] = None,
                 rate: float = 0.1):
        super(CAEncoder, self).__init__()

        self.d_model = d_model
        self.num_layers = num_layers

        self.input_vocab_size = input_vocab_size
        self.context_vocab_size = context_vocab_size

        # Embedding layer for input and context if needed
        if input_vocab_size is not None:
            self.input_embedding = tf.keras.layers.Embedding(input_vocab_size, d_model)
        if context_vocab_size is not None:
            self.context_embedding = tf.keras.layers.Embedding(context_vocab_size, d_model)
        self.positional_encoding = PositionalEncodingLayer(maximum_position_encoding, self.d_model)

        self.encoder_layers = [CAEncoderLayer(d_model, num_heads, dff, rate) for _ in range(num_layers)]

        self.dropout = tf.keras.layers.Dropout(rate)

    def __call__(self, inputs, context, training, mask):
        assert tf.shape(inputs)[0, 1] == tf.shape(context)[0, 1]
        attention_weights = {}
        seq_len = tf.shape(inputs)[1]

        # adding embedding and position encoding.
        if self.input_vocab_size is not None:
            inputs = self.input_embedding(inputs)  # (batch_size, input_seq_len, d_model)
        if self.context_vocab_size is not None:
            context = self.context_embedding(context) # (batch_size, input_seq_len, d_model)

        inputs = self.positional_encoding(inputs, seq_len)
        context = self.positional_encoding(context, seq_len)

        inputs = self.dropout(inputs, training=training)

        for idx, layer in enumerate(self.encoder_layers):
            inputs, weights = layer(inputs, context, training, mask)
            attention_weights[f'encoder_layer_{idx}'] = weights
        return inputs, context, attention_weights  # (batch_size, input_seq_len, d_model)


class CADecoder(tf.keras.models.Model):
    def __init__(self, num_layers: int, d_model: int, num_heads: int, dff: int, maximum_position_encoding: int,
                 input_vocab_size: Optional[int] = None, context_vocab_size: Optional[int] = None,
                 rate: float = 0.1):
        super(CADecoder, self).__init__()

        self.d_model = d_model
        self.num_layers = num_layers

        self.input_vocab_size = input_vocab_size
        self.context_vocab_size = context_vocab_size

        # Embedding layer for input and context if needed
        if input_vocab_size is not None:
            self.input_embedding = tf.keras.layers.Embedding(input_vocab_size, d_model)
        if context_vocab_size is not None:
            self.context_embedding = tf.keras.layers.Embedding(context_vocab_size, d_model)
        self.positional_encoding = PositionalEncodingLayer(maximum_position_encoding, self.d_model)

        self.encoder_layers = [CADecoderLayer(d_model, num_heads, dff, rate) for _ in range(num_layers)]

        self.dropout = tf.keras.layers.Dropout(rate)

    def __call__(self, inputs, input_context, enc_output, output_context, training, look_ahead_mask, padding_mask):
        assert tf.shape(inputs)[0, 1] == tf.shape(input_context)[0, 1]
        attention_weights = {}
        seq_len = tf.shape(inputs)[1]

        # adding embedding and position encoding.
        if self.input_vocab_size is not None:
            inputs = self.input_embedding(inputs)  # (batch_size, input_seq_len, d_model)
        if self.context_vocab_size is not None:
            input_context = self.context_embedding(input_context) # (batch_size, input_seq_len, d_model)

        inputs = self.positional_encoding(inputs, seq_len)
        input_context = self.positional_encoding(input_context, seq_len)

        inputs = self.dropout(inputs, training=training)

        for idx, layer in enumerate(self.encoder_layers):
            inputs, weights = layer(inputs, input_context, enc_output, output_context,
                                    training, look_ahead_mask, padding_mask)
            attention_weights[f'decoder_layer_{idx}'] = weights
        return inputs, attention_weights # (batch_size, input_seq_len, d_model)


class CATransformer(tf.keras.Model):
    def __init__(self, num_layers: int, d_model: int, num_heads: int, dff: int,
                 input_vocab_size: int, target_vocab_size: int, pe_input: int, pe_target: int, rate: float = 0.1):
        super(CATransformer, self).__init__()

        self.num_layers = num_layers
        self.d_model = d_model
        self.num_heads = num_heads
        self.dff = dff

        self.input_vocab_size = input_vocab_size
        self.target_vocab_size = target_vocab_size

        self.pe_input = pe_input
        self.pe_target = pe_target

        self.rate = rate

        self.encoder = CAEncoder(num_layers, d_model, num_heads, dff, pe_input, input_vocab_size, None, rate)
        self.decoder = CADecoder(num_layers, d_model, num_heads, dff, pe_target, target_vocab_size, None, rate)

        self.final_layer = tf.keras.layers.Dense(target_vocab_size)

    def __call__(self, inputs, input_context, targets, target_context, training, enc_padding_mask, look_ahead_mask, dec_padding_mask):
        # (batch_size, inp_seq_len, d_model)
        encoded_inputs, encoded_context, encoder_weights = self.encoder(inputs, input_context, training, enc_padding_mask)
        # dec_output.shape == (batch_size, tar_seq_len, d_model)
        decoded_inputs, decoder_weights = self.decoder(targets, target_context, encoded_inputs, encoded_context,
                                               training, look_ahead_mask, dec_padding_mask)
        # (batch_size, tar_seq_len, target_vocab_size)
        final_output = self.final_layer(decoded_inputs)

        return final_output, [encoder_weights, decoder_weights]

    @staticmethod
    @tf.function
    def create_masks(inp, tar):
        # Encoder padding mask
        enc_padding_mask = create_padding_mask(inp)

        # Used in the 2nd attention block in the decoder.
        # This padding mask is used to mask the encoder outputs.
        dec_padding_mask = create_padding_mask(inp)

        # Used in the 1st attention block in the decoder.
        # It is used to pad and mask future tokens in the input received by
        # the decoder.
        look_ahead_mask = create_look_ahead_mask(tf.shape(tar)[1])
        dec_target_padding_mask = create_padding_mask(tar)
        combined_mask = tf.maximum(dec_target_padding_mask, look_ahead_mask)

        return enc_padding_mask, combined_mask, dec_padding_mask

    @tf.function
    def train_step(self, inputs, input_context, targets, target_context, train_loss, train_metrics):

        enc_padding_mask, combined_mask, dec_padding_mask = self.create_masks(inputs, targets)

        with tf.GradientTape() as tape:
            predictions, _ = self(inputs, input_context, targets, target_context,
                                  True, enc_padding_mask, combined_mask, dec_padding_mask)
            loss = self.loss_function(targets, predictions)

            gradients = tape.gradient(loss, self.trainable_variables)
            # Make gradients and variables zip
            grads_and_vars = zip(gradients, self.trainable_variables)
            svd_indices = []
            # Optimize svd layers
            for layer in self._svd_layers:
                # Get layer components (U, S, V, W)
                layer_variables = layer.trainable_variables[:-1]
                # variable indices
                variable_indices = [idx for idx, v in enumerate(self.trainable_variables)
                                    if v.name in [var.name for var in layer_variables]]
                # Get gradients and variables for components
                u, s, v, w = layer_variables
                du, ds, dv, dw = array(gradients)[variable_indices]
                svd_indices = concatenate([svd_indices, variable_indices])
                # Calculate orthogonal update
                chi_u = chi(u, du, self.optimizer.learning_rate)
                chi_v = chi(v, dv, self.optimizer.learning_rate)
                u_update = u + chi_u @ u
                v_update = v + chi_v @ v
                # Context updated coefficients depending on encoder or decoder
                context = target_context if 'decoder' and ('values' or 'keys') in layer.name else input_context
                context = tf.reshape(context, (-1, context.shape[-1]))
                s_ = s + context @ w
                # calculate assembled gradient
                dk = batch_assembled_gradient(u, s_, v, du, ds, dv)
                # Calculate singular value updates
                psi_u = tf.transpose(u) @ chi_u @ u
                psi_v = tf.transpose(v) @ chi_v @ v
                s_matrix = tf.linalg.diag(s_)
                s_update_matrix = psi_u @ s_matrix + (s_matrix + psi_u @ s_matrix) @ tf.transpose(
                    psi_v) - self.optimizer.learning_rate * (
                                          tf.transpose(u_update) @ dk @ v_update + tf.linalg.diag(context @ dw)
                                  )
                # Update orthogonal matrices
                u.assign_add(chi_u @ u)
                v.assign_add(chi_v @ v)
                # Update singular values
                s.assign_add(tf.reduce_mean(tf.linalg.diag_part(s_update_matrix), axis=0))
                # regular updates
                w.assign_add(-self.optimizer.learning_rate * dw)
                # Optimize other variables
            self.optimizer.apply_gradients([(g, v) for idx, (g, v) in enumerate(grads_and_vars) if idx not in svd_indices])

        # Add train loss and metrics
        train_loss(loss)
        for train_metric in train_metrics:
            train_metric(targets, predictions)

    def train(self, train_ds: tf.keras.datasets.Dataset, optimizer: tf.keras.optimizers.Optimizer,
              validation_ds: Optional[tf.keras.datasets.Dataset] = None,
              epochs: int = 1, train_loss: str = 'mse', train_metrics=None, validation_metrics=None,
              verbose: int=1, save_ckpt: int = 5, ckpt_path: Optional[str] = None):
        """

        Parameters
        ----------
        train_ds
            train dataset
        optimizer
        validation_ds
        epochs
        train_loss
        train_metrics
        validation_metrics
        verbose
        save_ckpt
        ckpt_path

        Returns
        -------

        """
        # noinspection PyAttributeOutsideInit
        self._svd_layers = [layer for layer in unpack([self]) if 'svd' in layer.name]

        if ckpt_path is not None:
            _ckpt = tf.train.Checkpoint(transformer=self, optimizer=optimizer)
            _ckpt_manager=tf.train.CheckpointManager(_ckpt, ckpt_path, max_to_keep=5)

        train_loss = tf.keras.losses.get(train_loss)
        for epoch in range(epochs):
            # reset states
            train_loss.reset_states()
            for train_metric in train_metrics:
                train_metric.reset_states()
            if validation_metrics is not None:
                for validation_metric in validation_metrics:
                    validation_metric.reset_states()
            else:
                pass

            # training step
            for (batch, (inputs, input_context, targets, target_context)) in enumerate(train_ds):
                self.train_step(inputs, input_context, targets, target_context, train_loss, train_metrics)

            if (epoch + 1) % verbose == 0:
                print(f'Epoch {epoch}, Loss {train_loss:.4f}' + ', '.join(
                    [f'{train_metric.name}: {train_metric}' for train_metric in train_metrics]))
                print(f'Epoch {epoch}, Loss {train_loss:.4f}' + ', '.join(
                    [f'{val_metric.name}: {val_metric}' for val_metric in validation_metrics]))

            if ((epoch + 1) % save_ckpt == 0) & (ckpt_path is not None):
                # noinspection PyUnboundLocalVariable
                ckpt_save_path = _ckpt_manager.save()
                print('Saving checkpoint for epoch {} at {}'.format(epoch + 1, ckpt_save_path))

    def test(self, encoder_input: tf.Tensor, input_context, target_context, max_length: int):
        decoder_input = [self.target_vocab_size]
        output = tf.expand_dims(decoder_input, 0)
        for i in range(max_length):
            enc_padding_mask, combined_mask, dec_padding_mask = self.create_masks(
                encoder_input, output)

            # select context up till current token step
            context = target_context[0:, :i, :]

            # predictions.shape == (batch_size, seq_len, vocab_size)
            predictions, attention_weights = self(encoder_input, input_context,
                                                  output, context,
                                                  False, enc_padding_mask, combined_mask, dec_padding_mask)

            # select the last word from the seq_len dimension
            predictions = predictions[:, -1:, :]  # (batch_size, 1, vocab_size)

            predicted_id = tf.cast(tf.argmax(predictions, axis=-1), tf.int32)

            # return the result if the predicted_id is equal to the end token
            if predicted_id == self.target_vocab_size + 1:
                return tf.squeeze(output, axis=0), attention_weights

            # concatentate the predicted_id to the output which is given to the decoder
            # as its input.
            output = tf.concat([output, predicted_id], axis=-1)

        return tf.squeeze(output, axis=0), attention_weights


   # def evaluate(self, input_sentence, tokenizer, vocab_size):
    #     start_token = [vocab_size]
    #     end_token = [vocab_size + 1]
    #
    #     # inp sentence is portuguese, hence adding the start and end token
    #     inp_sentence = start_token + tokenizer.encode(input_sentence) + end_token
    #     encoder_input = tf.expand_dims(inp_sentence, 0)
    #
    #     # as the target is english, the first word to the transformer should be the
    #     # english start token.
    #     decoder_input = [vocab_size]
    #     output = tf.expand_dims(decoder_input, 0)